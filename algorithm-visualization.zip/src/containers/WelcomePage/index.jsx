import React, { Component } from 'react';

import styles from './App.css';

class WelComePage extends Component {
  render() {
    return (
      <div className={styles.App}>
        123
      </div>
    );
  }
}

export default WelComePage;