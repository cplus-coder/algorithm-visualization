const data = [
  {
    index: 0,
    pillar: 0,
    depth: 0
  },
  {
    index: 1,
    pillar: 0,
    depth: 1,
  }
]

export default data;