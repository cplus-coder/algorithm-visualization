// import wwl1 from '../assets/mmexport1513523949452.jpg';
// import wwl2 from '../assets/mmexport1513525855318.jpg';
// import wwl3 from '../assets/296a202288a2809c.jpg';
// import wwl4 from '../assets/3a88d71392765f29.jpg';
// import delete1 from '../assets/delete.png';
// import delete2 from '../assets/delete2.png';
// import load1 from '../assets/add.png';
// import load2 from '../assets/add2.png';

// const images = {
//     wwl1,
//     wwl2,
//     wwl3,
//     wwl4,
//     delete1,
//     delete2,
//     load1,
//     load2,
// }
// export default images;